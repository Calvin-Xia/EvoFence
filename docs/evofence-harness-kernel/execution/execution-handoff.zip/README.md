# EvoFence 暂停交接包

执行已由用户暂停，S02 未创建。先读 docs/evofence-harness-kernel/execution/PAUSED.md 与 SESSION-001-HANDOFF.md。不得自动恢复。

本包是基线 d47f88367564e65db026b43b4b1e4fd83f06a4b7 上的设计与执行资料，不含产品源码。当前原始图已完成 l1_review、l1_pi_probe；旧 graph-review.zip 仅为历史设计快照，未纳入本包。包含另一份未改的历史参考图，以保留多图导出边界。

先解压到独立目录核对 FILES-SHA256.json，不要覆盖已有 .graph。用户恢复后，在对应源码基线与新授权工作目录中导入本包；graph 的 index/snapshots/locks 是派生状态，可由 Super Plumber CLI 重建。保留 events、节点和历史，节点状态仅由 graph CLI 操作。

未含 credential、私有 holdout、ledger、Pi 私有 runtime、auth.json 或旧 ZIP；接手者须自行使用用户授权的环境凭据。模型预算总上限 $0.50，USD 参考估计剩余 $0.49801783，不是已确认账单。不要重置费用账。
