# EvoFence graph review bundle

Only planning sources; no runtime, ledger, credentials or holdout. Contains the new pending design and one unchanged historical reference graph to preserve multi-graph export layout. Extract into a separate review folder and run graph validate --graph evofence-harness-kernel; graph rebuild --graph evofence-harness-kernel; graph serve --no-open. Do not overwrite an existing .graph folder.
